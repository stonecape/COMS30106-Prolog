# Grid World assignment #
This repository contains *Grid World* assignment for University of Bristol [COMS30106](https://www.cs.bris.ac.uk/Teaching/Resources/COMS30106) course.

The coursework description is available in wiki format [here](https://github.com/COMS30106/assignment/wiki).
